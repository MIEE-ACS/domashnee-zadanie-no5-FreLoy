﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public class Date
    {
        int iDay;
        int iMonth;
        int iYear;       
        static int[] DayOfMonth = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        public int GetDay()
        {
            return iDay;
        }
        public int GetMonth()
        {
            return iMonth;
        }
        public int GetYear()
        {
            return iYear;
        }
        public Date(int Day, int Month, int Year)
        {
            iDay = Day;
            iMonth = Month;
            iYear = Year;
            CheckOfDate();
        }
        public void ChangeDay(int h)
        {
            iDay = h;
            CheckOfDate();
        }
        public void ChangeMonth(int m)
        {
            iMonth = m;
            CheckOfDate();
        }

        public void ChangeYear(int y)
        {
            iYear = y;
            CheckOfDate();
        }
        public void ChangeData(int n)
        {
            int n2 = n;
            iYear += n/365;
            n2 = n - (n / 365) * 365;          
            while (n2 > 0)
            {
                n2 -= DayOfMonth[iMonth - 1];
                if (n2 < 0) break;
                iMonth += 1;               
            }
            int SumOfDays = 0;
            for (int i = 0; i < iMonth - 1; i++)
            {
                SumOfDays += DayOfMonth[i];
            }
            iDay += (n - (n / 365) * 365) - SumOfDays;
        }
        void CheckOfDate()
        {
            try
            {
                if (iDay > 32 || iDay == 0)
                {
                    throw new ArgumentNullException();
                }
                if (iYear < 0)
                {
                    throw new ArgumentNullException();

                }
                if ((iMonth < 1) || (iMonth > 12))
                {
                    throw new ArgumentNullException();

                }
                if ((iDay < 0) || (iDay > DayOfMonth[iMonth - 1]))
                {
                    throw new ArgumentNullException();
                }
            }
            catch (Exception ex)
            {
                return;
            }
        }
    }
    
    
    public partial class MainWindow : Window
    {
        string[] separatingStrings = { "/", ";", "; ", "." };
        string[] xar; 
        public MainWindow()
        {
            InitializeComponent();
        }

        
        Date d = new Date(0, 0, 0);
        private void BT1_Click(object sender, RoutedEventArgs e)
        {            
            xar = TB1.Text.Split(separatingStrings, System.StringSplitOptions.RemoveEmptyEntries);
            d.ChangeDay (int.Parse(xar[0]));
            d.ChangeMonth(int.Parse(xar[1]));
            d.ChangeYear(int.Parse(xar[2]));
           
            TB2.Text = "";            
            TB2.Text = d.GetDay().ToString();            
       
            TB3.Text = "";           
            TB3.Text = d.GetMonth().ToString();
                      
            TB4.Text = "";
            TB4.Text = d.GetYear().ToString();
        }


        private void BT2_Click(object sender, RoutedEventArgs e)
        {
            d.ChangeData(int.Parse(TBIZM.Text));
            TB5.Text = "";
            TB5.Text = d.GetDay().ToString();

            TB6.Text = "";
            TB6.Text = d.GetMonth().ToString();

            TB7.Text = "";
            TB7.Text = d.GetYear().ToString();


            TB2.Text = "";
            TB2.Text = d.GetDay().ToString();

            TB3.Text = "";
            TB3.Text = d.GetMonth().ToString();

            TB4.Text = "";
            TB4.Text = d.GetYear().ToString();

            TB1.Text = "";
            TB1.Text += TB2.Text;
            TB1.Text += "/";
            TB1.Text += TB3.Text;
            TB1.Text += "/";
            TB1.Text += TB4.Text;
        }
              

        private void TB1_GotFocus(object sender, RoutedEventArgs e)
        {
            TB1.Text = "";
            TB2.Text = "";
            TB3.Text = "";
            TB4.Text = "";
        }

        private void TBIZM_GotFocus(object sender, RoutedEventArgs e)
        {
            TBIZM.Text = "";
            TB5.Text = "";
            TB6.Text = "";
            TB7.Text = "";
        }

        private void BT3_Click(object sender, RoutedEventArgs e)
        {
            TB2.Text = "";
            TB3.Text = "";
            TB4.Text = "";
            TB5.Text = "";
            TB6.Text = "";
            TB7.Text = "";
            BT2.IsEnabled = true;
        }
    }
}


    
    



